import random
from pi import pi

attempt = 10
radius = random.randint(1,10)
cubed = radius*radius*radius
fraction = 1.3333333333333333333333333333333333333333333333334
answer = fraction*pi*cubed
r_answer = round(answer , 2)

def user():
  global user
  user = float(input(f"What is the volume of a sphere if the radius is: {radius} "))

user()

if user == r_answer:
  print(f"Thats Correct the answer is {r_answer}.")
  print(f"you did it with {attempt} attempts left.")
else:
  print("Try again")
  attempt -= 1
  user()

while attempt > 1:
  print(f"You ran out of attempts, the answer was {r_answer}")